# ================================================================
#  make_map.R  —  Generate your choropleth map for the paper
#
#  INSTRUCTIONS:
#    1. Change DATA_FILE below to your actual CSV file name
#    2. Change FIPS_COL and OUTCOME_COL to your column names
#    3. Run this script in R
#    4. It saves  map.png  in the same folder
#    5. Upload map.png to the figures/ folder in Overleaf
#    6. In main.tex: comment out the \fbox block and
#       uncomment  \includegraphics[width=0.85\textwidth]{figures/map.png}
# ================================================================

library(tidyverse)
library(sf)
library(tigris)
library(viridis)

options(tigris_use_cache = TRUE)

# ── CHANGE THESE ────────────────────────────────────────────────
DATA_FILE   <- "your_data.csv"   # your data file (in the same folder)
FIPS_COL    <- "fips"            # column name for 5-digit county FIPS
OUTCOME_COL <- "outcome"         # column name for the variable to map
MAP_TITLE   <- "Your Map Title"
LEGEND_LABEL <- "Your Variable"
DATA_SOURCE  <- "Source: Your Data Source, Year"
STATE        <- "VA"             # 2-letter state abbreviation
# ────────────────────────────────────────────────────────────────

# Load county shapefile from Census
counties_sf <- counties(state = STATE, cb = TRUE, year = 2023,
                        progress_bar = FALSE) %>%
  st_transform(crs = 4326)

# Load your data
data <- read_csv(DATA_FILE) %>%
  mutate(across(all_of(FIPS_COL), as.character))

# Merge
map_data <- counties_sf %>%
  left_join(data, by = setNames(FIPS_COL, "GEOID"))

# Build plot
map_plot <- ggplot(map_data) +
  geom_sf(aes(fill = .data[[OUTCOME_COL]]),
          color = "white", linewidth = 0.25) +
  scale_fill_viridis_c(
    name     = LEGEND_LABEL,
    option   = "plasma",
    direction = -1,
    na.value = "gray85"
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position   = "right",
    legend.key.height = unit(1.2, "cm"),
    plot.title        = element_text(face = "bold", size = 14,
                                     margin = margin(b = 6)),
    plot.caption      = element_text(size = 8, color = "gray50",
                                     margin = margin(t = 8))
  ) +
  labs(
    title   = MAP_TITLE,
    caption = DATA_SOURCE
  )

# Save — upload this file to Overleaf figures/
ggsave("map.png",
       plot   = map_plot,
       width  = 8,
       height = 5.5,
       dpi    = 300,
       bg     = "white")

message("Saved: map.png  →  upload to figures/ in Overleaf")
