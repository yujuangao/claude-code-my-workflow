VT-DSPG 2026 Academic Paper Template — figures/ folder
=======================================================

Upload the following files to this folder in Overleaf:

YOUR MAP (main figure in the Results section):
  YOUR-MAP-FILENAME.png
    → Your choropleth map exported from R or ArcGIS/QGIS
    → After uploading, open main.tex and:
        1. Comment out the \fbox placeholder (add %% at start)
        2. Uncomment \includegraphics (remove %% from start)
        3. Replace YOUR-MAP-FILENAME.png with your actual filename

ADDITIONAL FIGURES (if needed):
    → Add other figures here (e.g., scatter plots, bar charts)
    → Reference in main.tex with:
         \includegraphics[width=0.8\textwidth]{figures/FILENAME.png}
    → Use \begin{figure}[H] ... \end{figure} to place them

FILE FORMAT TIPS:
  - PDF   best for vector graphics from R (ggplot2 → ggsave .pdf)
  - PNG   good for raster maps; export at 300 DPI minimum
  - JPEG  avoid for figures with text/lines (lossy compression)

RESOLUTION FOR PUBLICATION:
  - Minimum for submission: 300 DPI
  - Recommended: 600 DPI for line art / maps
  - For a full-width figure (6.5"): export at ~2000 × 1500 pixels

EXPORTING FROM R (example):
  ggsave("figures/map_snap_access.pdf",
         plot   = my_map,
         width  = 6.5,
         height = 5,
         units  = "in",
         dpi    = 300)

HOW TO UPLOAD IN OVERLEAF:
  1. Click the figures/ folder in the Overleaf file tree (left panel)
  2. Click the Upload icon (upward arrow)
  3. Drag and drop your file, or click Browse
  4. It appears in the figures/ folder immediately
